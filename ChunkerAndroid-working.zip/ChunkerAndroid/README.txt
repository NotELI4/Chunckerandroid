Chunker Android Version 1

This is a clean installation-test build. It intentionally does not include the old desktop Chunker core.
The app opens and lets you choose a folder. Later versions will add the Chunker-style interface and conversion engine.
