package com.hivemc.chunker.util;

/**
 * Minimal drop-in replacement for java.awt.Color, which doesn't exist on Android.
 * Only implements the constructors/methods Chunker's codebase actually calls
 * (a plain packed-ARGB int container) — not a general-purpose color class.
 */
public class Color {
    private final int argb;

    /**
     * Create an opaque color from a packed RGB int (alpha forced to 255),
     * matching java.awt.Color(int rgb).
     */
    public Color(int rgb) {
        this.argb = 0xFF000000 | rgb;
    }

    /**
     * Create a color from separate channels, matching java.awt.Color(int r, int g, int b, int a).
     */
    public Color(int r, int g, int b, int a) {
        this.argb = ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }

    /**
     * Matches java.awt.Color(int rgba, boolean hasAlpha). When hasAlpha is true, all four
     * bytes of rgba are used as ARGB; when false, the top byte is ignored and alpha is
     * forced to fully opaque (255).
     */
    public Color(int rgba, boolean hasAlpha) {
        this.argb = hasAlpha ? rgba : (0xFF000000 | rgba);
    }

    /** Matches java.awt.Color#getRGB() — returns the packed ARGB int. */
    public int getRGB() {
        return argb;
    }

    public int getRed() {
        return (argb >> 16) & 0xFF;
    }

    public int getGreen() {
        return (argb >> 8) & 0xFF;
    }

    public int getBlue() {
        return argb & 0xFF;
    }

    public int getAlpha() {
        return (argb >> 24) & 0xFF;
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof Color && ((Color) obj).argb == this.argb;
    }

    @Override
    public int hashCode() {
        return argb;
    }
}
