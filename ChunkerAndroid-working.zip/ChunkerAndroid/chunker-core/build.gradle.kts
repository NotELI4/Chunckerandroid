plugins {
    id("com.android.library")
}

android {
    namespace = "com.hivemc.chunker"
    compileSdk = 34

    defaultConfig {
        minSdk = 26 // Java 17 desugaring support wants API 26+
    }

    compileOptions {
        // The real chunker-cli source targets Java 17. Android needs core
        // library desugaring to support newer java.* APIs on older devices.
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // Mirrors cli/build.gradle.kts's real dependency list (see gradle/libs.versions.toml
    // in the upstream repo). None of these are desktop-only, so they should resolve
    // fine on Android as-is.
    implementation("info.picocli:picocli:4.7.7")           // only needed if you keep CLI arg parsing; safe to drop otherwise
    implementation("org.jetbrains:annotations:26.1.0")
    implementation("it.unimi.dsi:fastutil:8.5.19")
    implementation("com.github.ben-manes.caffeine:caffeine:3.2.4")
    implementation("com.google.guava:guava:33.7.1-jre")
    implementation("com.google.code.gson:gson:2.14.0")
    implementation("net.jpountz.lz4:lz4:1.3.0")
    implementation("com.hivemc.leveldb:leveldb-api:1.1.0")
    implementation("com.hivemc.leveldb:leveldb:1.1.0")

    // The preview package itself (already copied into src/main/java) only needed
    // guava + fastutil, confirmed by inspecting the real source — no AWT deps to
    // remove from the classpath, since it never depended on javax.imageio either;
    // that usage lived directly in PreviewColumnWriter.java and has been patched.
}
