# ChunkerAndroid — project scaffold

This is a starting skeleton for an Android front-end to Chunker
(https://github.com/HiveGamesOSS/Chunker), reusing its existing Java
conversion engine instead of rewriting it.

## Module layout

- **`app/`** — the Android UI, built with Jetpack Compose. `ConversionScreen.kt`
  currently matches the visual mockup we designed: a world card with a map
  preview slot, an output-format picker, and quick-access buttons for
  mappings/pruning/dimension settings. It's UI-only right now — nothing is
  wired to a real conversion yet.

- **`chunker-core/`** — empty on purpose. This is where the actual
  `cli/src/main/java/...` source from the upstream Chunker repo goes,
  recompiled as an Android library instead of a desktop JAR.

## Status: map preview — confirmed and patched

Inspected the real upstream source (`cli/src/main/java/com/hivemc/chunker/conversion/encoding/preview/`).
Findings:

- `PreviewColumnWriter.writeColumn()` computes a plain `int[] argb` per chunk
  using nothing but block-color lookups — zero AWT dependency, compiles for
  Android untouched.
- The **only** desktop-only calls in the entire preview package were three
  lines in `PreviewColumnWriter.flushColumns()`: constructing a
  `BufferedImage`, `image.setRGB(...)`, and `ImageIO.write(...)` to encode
  the final per-region PNG.
- `PreviewWorldWriter` and `PreviewLevelWriter` have no desktop-only calls
  at all (plain `File`/`DataOutputStream`/`BitSet`) and are copied in
  unmodified.
- `chunker-core/src/main/java/.../preview/PreviewColumnWriter.java` here is
  the patched version: `BufferedImage` → `Bitmap.createBitmap(...)`,
  `setRGB` → `Bitmap#setPixels` (same data, slightly different argument
  order), `ImageIO.write` → `Bitmap.compress(PNG, ..., FileOutputStream)`.
  Everything else in the file is byte-for-byte the original.
- Preview PNGs are written to the app's own output folder (not a
  user-picked world folder), so plain `java.io.File` works fine here —
  no Storage Access Framework handling needed for this particular writer.

## Status: full cli source copied in and patched

The entire `cli/src/main/java` tree (978 files) is now copied into
`chunker-core/src/main/java`, including the `Messenger` protocol classes
(`com.hivemc.chunker.cli.messenger`) that define the JSON message format
for driving conversion and reporting progress.

A full sweep for `java.awt.*` / `javax.imageio.*` (neither exists on
Android) found **14 files total**, all fixed:

- **`PreviewColumnWriter.java`** (map preview) — already patched, see above.
- **`ChunkerMap.java`** and **`SettingsLevelWriter.java`** — both used
  `BufferedImage`/`ImageIO` for map-image PNG I/O (in-game item maps, a
  different feature from the world preview). Patched to
  `android.graphics.Bitmap`/`BitmapFactory` the same way.
- **11 other files** only used `java.awt.Color` as a plain RGB(A) data
  holder (dye colors, cauldron water tint, firework colors, item display
  tints) — nothing graphical. Since Android has no equivalent object type
  (`android.graphics.Color` is static methods only, not a class you can
  instantiate), these now use a small drop-in replacement at
  `com.hivemc.chunker.util.Color` that implements exactly the constructors
  and getters Chunker's code calls. No changes needed inside those 11
  files themselves — just their import line.

**Known remaining risk, not yet fixed:** the JAVA/BEDROCK readers still
open world files with `RandomAccessFile` and `File.listFiles()`, which
assume a real filesystem path. The planned fix (see below) is to copy a
user-picked world folder into the app's private storage before handing
it to any of this code, rather than modifying the reader/writer classes
directly — sidesteps the problem entirely for a much smaller amount of
new code.

## Next steps, in order

1. **Build a copy-in/copy-out step in the UI layer.** Use
   `ActivityResultContracts.OpenDocumentTree` to let the user pick a
   world folder, copy its contents into the app's private storage with
   `DocumentFile`/`ContentResolver` (regular `File` APIs from there on),
   run the existing unmodified Chunker engine against that private copy,
   then copy the result back out through the same picker.

2. **Wire up the Messenger protocol** in Kotlin, using the message
   classes already present in `chunker-core/.../cli/messenger` as the
   schema reference, so the UI can drive conversion and receive progress
   without needing a rewrite of that protocol. Chunker's cli already exposes a
   JSON-based message protocol for driving conversion and reporting
   progress (this is what the Electron frontend talks to). Reimplement a
   thin Kotlin client for that same protocol in `app/`, calling into
   `chunker-core` in-process instead of over a socket to a separate process.

4. **Wire the world picker to Android's file access.** Use
   `ActivityResultContracts.OpenDocumentTree` to let the user pick a world
   folder, then adapt however chunker-core reads world files (`File` based)
   to read via `DocumentFile`/`ContentResolver` instead.

5. **Hook `WorldSummary.preview` up for real** once step 2 is done — the
   Compose screen already has the slot ready for a `Bitmap`.

## Opening this project

Open the `ChunkerAndroid/` folder directly in Android Studio (Koala or
newer) — it'll pick up `settings.gradle.kts` automatically. Nothing will
do anything useful yet beyond showing the static screen, since
`chunker-core` has no real conversion logic in it until step 1 above is
done.
