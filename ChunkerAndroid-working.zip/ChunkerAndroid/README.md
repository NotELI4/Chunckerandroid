# ChunkerAndroid — merged and fixed

You sent a lot of attempts, so here's what I actually found in them and what
this zip changes.

## What went wrong in your builds

Looking at your GitHub Actions logs, in order:

1. **`ChunkerBlockIdentifier.java:288: bad operand type int for unary
   operator '!'`** and **`BedrockCauldronBlockEntityHandler.java: no
   suitable constructor found for Color(int,boolean)`** — these came from
   an earlier patch attempt (not from me) that ran into the same
   `java.awt` problem I'd already solved, independently, and introduced
   some new bugs while doing it.
2. **A javac internal crash** in a later attempt — a different symptom,
   likely from a corrupted/partial edit to a source file.
3. **The most recent failure**: `uses-sdk:minSdkVersion 23 cannot be
   smaller than version 26 declared in library [:chunker-core]` — this
   one's simple: your `app` module and `chunker-core` module disagreed on
   the minimum Android version. Whatever attempt produced this had
   `chunker-core` at minSdk 26 but `app` at 23.

I also caught a bug of my own before it could bite you: my `Color` shim
(the Android replacement for `java.awt.Color`) was missing the
`Color(int, boolean)` two-argument constructor, which
`BedrockCauldronBlockEntityHandler.java` actually calls. My first sweep's
search pattern truncated on nested parentheses and silently missed it —
now fixed and verified against every real `new Color(...)` call site in
the codebase, one by one.

## What this zip is

This merges your **`ChunkerAndroid-working.zip`** (your minimal,
proven-building app shell — folder picker, real Gradle wrapper, correct
minSdk 26) with my fully-patched `chunker-core` module (the complete
Chunker engine source, with every `java.awt`/`javax.imageio` call site
replaced with Android equivalents — see the previous zip's notes for the
full list). Both modules now agree on minSdk 26, and `app` has been
wired to actually depend on `chunker-core` so it gets compiled.

I also included a clean `.github/workflows/build-apk.yml` that builds a
debug APK and uploads it as a downloadable artifact — replace whatever's
currently in your repo's `.github/workflows/` folder with this one.

## What I still can't verify

I don't have Android SDK/Gradle available where I work, so I still
haven't compiled this myself — it's reasoned through carefully against
the real error messages you sent me, not tested. Push this, let the
Action run, and if it fails, send me the log zip (Actions tab → the
failed run → the ⚙️ icon → "Download log archive") the same way you did
this time — that's exactly how I found the real bugs above instead of
guessing.

## Important: a successful build ≠ a working converter yet

Some of your uploads (`ChunkerAndroid-APK.zip`, `ChunkerAndroid-APK__1_.zip`)
already contain a *built* APK. If you installed one of those and it
"didn't work" in the sense of not actually converting a world — that's
expected, not a bug. The UI (folder picker) and the engine (`chunker-core`)
aren't wired together yet. Right now, successfully installing this app
should get you a screen that lets you pick a folder and not much else.
The next real milestone is connecting the two — see the previous zip's
README for the Messenger-protocol plan for that.

If "non-functional" meant something else (crashes on open, blank screen,
etc.), let me know what you saw and I'll dig into that specifically.
