# Building this from your phone (no computer required)

This guide assumes you only have an Android phone/tablet and a browser —
no desktop computer, no Android Studio. You will not need to understand
any of the code. You'll type a few commands into a text box (a "terminal")
and I'll help interpret whatever it prints back.

## What we're using and why

Android Studio itself won't run on a phone — that's a hardware limitation,
not something any setting fixes. But Android Studio is really just a
convenient wrapper around two things that *can* run on a plain Linux
computer with no graphical interface at all: a Java toolchain, and
Google's Android SDK command-line tools. **GitHub Codespaces** gives you
exactly that — a free Linux computer in the cloud, accessed entirely
through your phone's browser, with a text-based terminal instead of
buttons to click.

Because your phone is Android, once this builds successfully, you'll be
able to download the resulting `.apk` file straight to your phone and
install it directly — no app store, no separate emulator needed.

## Step 1 — Create a GitHub account

Go to **github.com** in your phone's browser and sign up (it's free).
This is just an account, like signing up for email.

## Step 2 — Create a new repository

1. Tap the **+** icon (usually top-right) → **New repository**.
2. Give it any name, e.g. `chunker-android`.
3. Leave everything else default, tap **Create repository**.

## Step 3 — Upload the project

1. On your new (empty) repository page, tap **uploading an existing file**
   (or **Add file → Upload files**).
2. Upload the `ChunkerAndroid.zip` file from this conversation — as a
   single `.zip`, which is easy to select on a phone.
3. Tap **Commit changes** to save it.

## Step 4 — Open it in a Codespace

1. On the repository page, tap the green **Code** button.
2. Switch to the **Codespaces** tab.
3. Tap **Create codespace on main**.

This takes 30–60 seconds to spin up. You'll land in a VS Code-like screen
running in your browser, with a file list on one side and, importantly,
a **terminal** — a black text box you can type commands into. Tap it to
select it before typing.

## Step 5 — Unzip the project

Type this into the terminal and press enter:

```
unzip ChunkerAndroid.zip -d chunker-project && cd chunker-project
```

## Step 6 — Install the Android build tools

Copy and paste this whole block into the terminal and press enter (it'll
take a few minutes the first time):

```
sudo apt-get update -y && sudo apt-get install -y openjdk-17-jdk unzip wget
mkdir -p ~/android-sdk/cmdline-tools
cd ~/android-sdk/cmdline-tools
wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O tools.zip
unzip -q tools.zip && mv cmdline-tools latest
cd ~
export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
echo 'export ANDROID_HOME=~/android-sdk' >> ~/.bashrc
echo 'export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/34.0.0' >> ~/.bashrc
source ~/.bashrc
```

If any line in this block prints something starting with "error" in red
text, stop and send me a screenshot or copy of the text — don't guess
at fixing it yourself.

## Step 7 — Build it

```
cd ~/chunker-project/ChunkerAndroid
gradle wrapper
./gradlew assembleDebug
```

This is the step most likely to show errors on the first try, given how
large and untested this codebase still is — that's expected, not a sign
you did something wrong. Copy the terminal output (especially any red
text) and send it to me; I'll tell you exactly what to change.

## Step 8 — Get the app onto your phone

If it succeeds, the built file will be at:

```
ChunkerAndroid/app/build/outputs/apk/debug/app-debug.apk
```

Right-click (long-press) that file in the Codespaces file list on the
left and choose **Download**. Your phone will save it like any other
download. Open it from your phone's Downloads/Files app to install it —
Android will likely ask you to allow "install unknown apps" for your
browser the first time, which is normal for anything installed outside
the Play Store.

## A realistic expectation to set

This codebase is large and I haven't been able to compile any of it
myself yet (I don't have this tooling available where I work). The very
likely outcome of Step 7 the first time is a list of errors — missing
classes, version mismatches, that kind of thing. That's a normal part of
a project this size, not a sign it's broken beyond fixing. Paste me the
errors as they come up and we'll work through them one at a time.
