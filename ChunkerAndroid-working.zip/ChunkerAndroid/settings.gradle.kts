pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "ChunkerAndroid"

// "app" is the Android UI (Compose) — the part we're building fresh.
// "chunker-core" is where the recompiled Chunker `cli` Java source lives,
// exposed as a plain Android library module so `app` can call into it.
include(":app")
include(":chunker-core")
