package com.hivemc.chunkerandroid.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hivemc.chunkerandroid.core.AndroidChunker

private val Bg = Color(0xFF1B1D1F)
private val CardBg = Color(0xFF242629)
private val TextPrimary = Color(0xFFE7E7E5)
private val TextSecondary = Color(0xFF8A8C8F)
private val AccentGreen = Color(0xFF5DCAA5)
private val AccentGreenText = Color(0xFF04342C)

@Composable
fun ConversionScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val engine = remember { AndroidChunker(context) }
    var world by remember { mutableStateOf<AndroidChunker.DetectedWorld?>(null) }
    var outputFormat by remember { mutableStateOf("Bedrock_R21_50") }
    var progress by remember { mutableStateOf(0.0) }
    var status by remember { mutableStateOf("Select a Minecraft world to begin.") }
    var busy by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf<java.io.File?>(null) }

    val worldPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        status = "Reading world…"
        Thread {
            try {
                val imported = engine.importTree(uri)
                val detected = engine.detectWorld(imported, imported.name)
                world = detected
                outputFormat = if (detected.format.equals("Java_26_3", true)) "Bedrock_R21_50" else "Java"
                status = "World loaded. Ready to convert."
            } catch (t: Throwable) {
                status = t.message ?: "Could not open that world."
                world = null
            } finally { busy = false }
        }.start()
    }

    val destinationPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        val file = pendingExport ?: return@rememberLauncherForActivityResult
        if (uri == null) { status = "Export cancelled."; pendingExport = null; return@rememberLauncherForActivityResult }
        Thread {
            try {
                engine.exportTree(file, uri, (world?.name ?: "Converted World") + " Converted")
                status = "Conversion complete. The converted world was exported."
            } catch (t: Throwable) {
                status = t.message ?: "Could not export the converted world."
            } finally { pendingExport = null }
        }.start()
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Text("Chunker", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(14.dp))

        Column(Modifier.fillMaxWidth().background(CardBg, RoundedCornerShape(14.dp)).padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(world?.name ?: "No world selected", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(world?.let { "${it.format} ${it.version}" } ?: "—", color = AccentGreen, fontSize = 11.sp)
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { worldPicker.launch(null) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Choose world") }
        }

        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().background(CardBg, RoundedCornerShape(14.dp)).padding(12.dp)) {
            Text("Output format", color = TextSecondary, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Text(outputFormat, color = TextPrimary, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text("First milestone: Java ↔ Bedrock conversion. More formats can be added later.", color = TextSecondary, fontSize = 11.sp)
        }

        Spacer(Modifier.height(12.dp))
        Text(status, color = TextSecondary, fontSize = 12.sp)
        if (busy || progress > 0.0) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { progress.toFloat() }, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.weight(1f))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { engine.cancel(); status = "Cancelling…" }, enabled = busy, modifier = Modifier.weight(1f)) { Text("Cancel") }
            Button(
                onClick = {
                    val selected = world ?: return@Button
                    busy = true; progress = 0.0; status = "Starting conversion…"
                    engine.convert(selected.sourceDir, outputFormat, { p -> progress = p }, { m -> status = m })
                        .whenComplete { result, error ->
                            busy = false
                            if (error != null) status = error.message ?: "Conversion failed."
                            else if (result != null) {
                                progress = 1.0
                                pendingExport = result.outputDir
                                status = "Conversion finished. Choose where to save the converted world."
                                destinationPicker.launch(null)
                            }
                        }
                },
                enabled = world != null && !busy,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = AccentGreen, contentColor = AccentGreenText)
            ) { Text("Convert world") }
        }
    }
}
