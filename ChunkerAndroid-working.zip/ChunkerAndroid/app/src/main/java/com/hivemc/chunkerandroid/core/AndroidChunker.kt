package com.hivemc.chunkerandroid.core

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.hivemc.chunker.cli.messenger.Messenger
import com.hivemc.chunker.conversion.WorldConverter
import com.hivemc.chunker.conversion.encoding.EncodingType
import com.hivemc.chunker.conversion.encoding.base.reader.LevelReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.CompletableFuture

/** Android-facing bridge around the existing Chunker conversion engine. */
class AndroidChunker(private val context: Context) {
    data class DetectedWorld(
        val name: String,
        val format: String,
        val version: String,
        val sourceDir: File
    )

    data class ConversionResult(val outputDir: File, val cancelled: Boolean)

    private var activeConverter: WorldConverter? = null

    fun importTree(uri: Uri, nameHint: String = "World"): File {
        val destination = File(context.cacheDir, "imports/${UUID.randomUUID()}")
        destination.mkdirs()
        val root = DocumentFile.fromTreeUri(context, uri)
            ?: error("Android could not open the selected folder.")
        copyTree(root, destination)
        return destination
    }

    fun detectWorld(source: File, nameHint: String = source.name): DetectedWorld {
        val converter = WorldConverter(UUID.randomUUID())
        val reader = EncodingType.findReader(source, converter).orElseThrow {
            IllegalArgumentException("Chunker could not recognize this world as a supported Java or Bedrock world.")
        }
        return DetectedWorld(nameHint, reader.getEncodingType().name, reader.getVersion().toString(), source)
    }

    fun convert(
        source: File,
        outputFormat: String,
        onProgress: (Double) -> Unit,
        onMessage: (String) -> Unit
    ): CompletableFuture<ConversionResult> {
        val future = CompletableFuture<ConversionResult>()
        val converter = WorldConverter(UUID.randomUUID())
        activeConverter = converter
        val output = File(context.cacheDir, "exports/${UUID.randomUUID()}").apply { mkdirs() }

        try {
            val reader: LevelReader = EncodingType.findReader(source, converter).orElseThrow {
                IllegalArgumentException("The selected world format is not supported.")
            }
            val writer = Messenger.findWriter(outputFormat, converter, output).orElseThrow {
                IllegalArgumentException("Output format '$outputFormat' is not supported by this Chunker build.")
            }
            onMessage("Converting ${reader.getEncodingType().name} ${reader.getVersion()} to ${writer.getEncodingType().name} ${writer.getVersion()}")
            val task = converter.convert(reader, writer)

            Thread {
                try {
                    while (!task.future().isDone) {
                        onProgress(task.progress.coerceIn(0.0, 1.0))
                        Thread.sleep(250)
                    }
                    task.future().join()
                    onProgress(1.0)
                    future.complete(ConversionResult(output, converter.isCancelled()))
                } catch (t: Throwable) {
                    future.completeExceptionally(t.cause ?: t)
                } finally {
                    activeConverter = null
                }
            }.start()
        } catch (t: Throwable) {
            activeConverter = null
            future.completeExceptionally(t.cause ?: t)
        }
        return future
    }

    fun cancel() {
        activeConverter?.cancel(null)
    }

    fun exportTree(source: File, destinationTree: Uri, outputName: String): Uri {
        val root = DocumentFile.fromTreeUri(context, destinationTree)
            ?: error("Android could not open the selected destination folder.")
        val target = root.createDirectory(uniqueName(root, outputName))
            ?: error("Could not create the converted world folder.")
        copyFileTreeToDocument(source, target)
        return target.uri
    }

    private fun copyTree(source: DocumentFile, destination: File) {
        source.listFiles().forEach { child ->
            val safeName = child.name ?: "unnamed"
            if (child.isDirectory) {
                val dir = File(destination, safeName).apply { mkdirs() }
                copyTree(child, dir)
            } else if (child.isFile) {
                child.uri.let { uri ->
                    context.contentResolver.openInputStream(uri).use { input ->
                        requireNotNull(input) { "Could not read $safeName" }
                        FileOutputStream(File(destination, safeName)).use { output -> input.copyTo(output) }
                    }
                }
            }
        }
    }

    private fun copyFileTreeToDocument(source: File, destination: DocumentFile) {
        source.listFiles()?.forEach { child ->
            if (child.isDirectory) {
                val dir = destination.createDirectory(child.name ?: "folder") ?: error("Could not create output folder.")
                copyFileTreeToDocument(child, dir)
            } else {
                val file = destination.createFile("application/octet-stream", child.name ?: "file")
                    ?: error("Could not create output file.")
                context.contentResolver.openOutputStream(file.uri).use { output ->
                    requireNotNull(output) { "Could not open output file." }
                    FileInputStream(child).use { input -> input.copyTo(output) }
                }
            }
        }
    }

    private fun uniqueName(parent: DocumentFile, requested: String): String {
        var name = requested.ifBlank { "Converted World" }
        var index = 2
        while (parent.findFile(name) != null) name = "${requested} ($index)"
        return name
    }
}
