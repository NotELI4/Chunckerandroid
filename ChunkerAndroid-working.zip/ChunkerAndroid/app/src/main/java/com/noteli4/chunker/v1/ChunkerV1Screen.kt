package com.noteli4.chunker.v1

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ChunkerV1Screen() {
    var selectedFolder by rememberSaveable { mutableStateOf("") }
    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        selectedFolder = uri?.toString().orEmpty()
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text(
                    text = "Chunker",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "Version 1 installation test",
                    style = MaterialTheme.typography.titleMedium
                )
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "The app is running.",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "This first version only tests that Chunker can open and choose a folder. World conversion and the full design will be added later.",
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
                Button(
                    onClick = { folderPicker.launch(null) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Choose a folder")
                }
                Text(
                    text = if (selectedFolder.isBlank()) {
                        "No folder selected yet."
                    } else {
                        "Selected folder:\n$selectedFolder"
                    }
                )
            }
        }
    }
}
